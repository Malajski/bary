﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace Progreskibarki
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }
        public static class ModifyProgressBarColor
        {
            [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = false)]
            static extern IntPtr SendMessage(IntPtr hWnd, uint Msg, IntPtr w, IntPtr l);
            public static void SetState(this ProgressBar pBar, int state)
            {
                SendMessage(pBar.Handle, 1040, (IntPtr)state, IntPtr.Zero);
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Random los = new Random();
            int x = los.Next(100)+1;
            int y = los.Next(100) + 1;
            int z = los.Next(100) + 1;
            int a = los.Next(100) + 1;
            int v = los.Next(100) + 1;
            int c = los.Next(100) + 1;
            int b = los.Next(100) + 1;
            int f = los.Next(100) + 1;
            int g = los.Next(100) + 1;
            int o = los.Next(100) + 1;
            //int y = los.Next();
            progressBar1.Value = x;
            progressBar2.Value = g;
            progressBar3.Value = f;
            progressBar4.Value = c;
            progressBar5.Value = v;
            progressBar6.Value = z;
            progressBar7.Value = b;
            
            progressBar10.Value = o;

        }
         
        private void Form1_Load(object sender, EventArgs e)
        {
            ModifyProgressBarColor.SetState(progressBar1, 2);
        }

        private void progressBar3_Click(object sender, EventArgs e)
        {

        }
    }
}
